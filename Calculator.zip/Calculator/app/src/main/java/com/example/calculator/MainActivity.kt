package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    private fun getNumbers(): Pair<Double, Double>? {
        val n1 = findViewById<EditText>(R.id.n1).text.toString().toDoubleOrNull()
        val n2 = findViewById<EditText>(R.id.n2).text.toString().toDoubleOrNull()

        if (n1 == null || n2 == null) {
            AlertDialog.Builder(this)
                .setTitle("Input required")
                .setMessage("Please enter both numbers. ")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss() }
                .show()
            return null
        } else {
            return Pair(n1, n2)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val n1 = findViewById<EditText>(R.id.n1)
        val n2 = findViewById<EditText>(R.id.n2)
        val plus = findViewById<Button>(R.id.plus)
        val minus = findViewById<Button>(R.id.minus)
        val multiply = findViewById<Button>(R.id.multiply)
        val divide = findViewById<Button>(R.id.divide)
        val result = findViewById<TextView>(R.id.result)
        val clear = findViewById<Button>(R.id.clear)

        clear.setOnClickListener {
            n1.text.clear()
            n2.text.clear()
            result.text = ""
        }

        plus.setOnClickListener {
            val (num1, num2) = getNumbers() ?: return@setOnClickListener
                val sum = num1 + num2
                result.text = sum.toString()
        }

        minus.setOnClickListener {
            val (num1, num2) = getNumbers() ?: return@setOnClickListener
            val sum = num1 - num2
            result.text = sum.toString()
        }

        multiply.setOnClickListener {
            val (num1, num2) = getNumbers() ?: return@setOnClickListener
            val sum = num1 * num2
            result.text = sum.toString()
        }

        divide.setOnClickListener {
            val (num1, num2) = getNumbers() ?: return@setOnClickListener

            if (num2 == 0.0) {
                AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage("You cannot divide by zero.")
                    .setPositiveButton("OK") { dialog, _ ->
                        dialog.dismiss() }
                    .show()
            } else {
                val sum = num1 / num2
                result.text = sum.toString()
            }
        }
    }
}